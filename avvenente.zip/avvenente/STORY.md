# STORY — AVVENENTE (Kaatsheuvel)

Источник фактов: BRIEF.md. Палитра: PALETTE.md («Aubergine & Candle»: --bg #1A0B2A, --surface #271639, --light #F5EEE4, --muted #B3A6C2, --accent #FFA552, --line #3A2A4C). Шрифты: TYPE.md (Red Hat Display 300 / Instrument Sans 400–500).
Главное правило: ★ ГЛАВНЫЙ СТИЛЬ DESIGN_STANDARD (кино-тёмная премиум-студия, один общий фон, без стыков, движение в каждой секции, ≥4 страницы) + §2a, §9 (сквозная история), §10 (текст ≥900 слов NL на главной), §11 (живой фото-фон в каждой главе).
Каркас вёрстки = sites/scena-piekna (`.story` / `.story__stage` sticky / `.scene` / `.halo` / `canvas.fx[data-fx]` / `.story__hshade` / `.story__panel > .acts > article.act` / `.dots` / `.story__fade` / `.curtain` / `.split` / `.reveal` / `[data-par]` / `.glass`). Новое — только то, что описано ниже.
Язык сайта: только NL.

---

## 1. Концепция
**«Van vlam tot vingertop.»** Главный объект — **огонёк соевой свечи** (фирменная деталь салона из отзывов: «ontspannen sfeer» и sojakaarsen). Его тёплый свет — это «камера» сайта: он путешествует.
Свеча в стеклянной баночке → камера ныряет в лужицу расплавленного воска → капля воска превращается в каплю BIAB-геля на кисти → гель растекается по ногтям (молочный nude) → ногти «заливаются» баклажановым цветом с оранжевым бликом свечи → блик пролетает к глазу и раскрывается веером Russian volume → тёплый пар над полотенцем, ухоженные стопы → камера отъезжает: это студия, полная свечей → через окно выходим на вечернюю Peperstraat → затемнение → финал.
Огонь всегда присутствует в кадре как свет (контровой блик, отражение, огонёк), а кодом его «ведёт» один и тот же элемент `.flame-light` (радиальное свечение --accent, mix-blend:screen), который переезжает из точки в точку между главами — это и есть невидимая нить без стыков.

Кадры в ОДНОМ якоре (§8): та же камера (85 mm, уровень глаз, лёгкий ракурс 3/4), тот же low-key свет (тёплый ключ от свечи справа-снизу, мягкий ivory-контур сверху), тот же баклажановый «мир» без горизонта, объект справа/по центру, левые ~42% кадра пустые и тёмные под текст.

---

## 2. Техническая схема главной
```
<section class="story" style="height:1150vh">            ← P = 0..1
  <div class="story__stage"> (sticky, 100svh)
    .bgs > img.bg.bg-0 … bg-8     ← 16:9 кадры, object-fit:cover; mobile object-position по точке объекта (OX)
            смена: маска главы (см. каждую главу) + Ken Burns 1.06→1.0 внутри главы
    .bigword                       ← строчное слово Red Hat Display 300, 24vw, rgba(245,238,228,.06),
                                     ПОД .bgs; .bgs mix-blend-mode:lighten → слово видно на тёмной пустоте, прячется за светлым объектом
    .flame-light                   ← «путешествующий свет»: radial-gradient(#FFA552 → transparent), 28vmin, screen,
                                     мерцание (flick: scale .96–1.04 + opacity .75–1, шум 3 частот), координаты = OX/OY текущей главы,
                                     между главами летит по кривой Безье (CSS offset-path или lerp в JS)
    svg.lines                      ← код-слой: капля, контуры ногтей, French-кончики, веер ресниц, линия «тёплой воды»
    canvas.fx--story[data-fx=embers]  ← тёплые искры/пылинки --accent, opacity .15–.45, медленно вверх; в гл.6 — пар
    .hero__haze                    ← тёплая дымка от фитиля (2 слоя, blur 60px, дрейф 18 s / 27 s)
    .story__hshade / .story__shade ← левый градиент под текст (как scena-piekna)
    .story__hero                   ← текст hero; растворяется P 0–.06
    .story__panel > article.act ×8 ← главы: «Hoofdstuk 2 van 8» (мелко), h2 split по словам, 2–4 абзаца, факты
    .story__rail                   ← счётчик «03 / 08» + точки, справа снизу; клик = lenis.scrollTo(главы)
    .story__fade                   ← P .95–1 уход в --bg
```
- Lenis lerp .09; доводка до ближайшей главы после остановки (scrollTo 500 ms, только при малой скорости, off при reduced-motion).
- Локальный прогресс главы p = 0..1: маска перехода p 0–.28, Ken Burns весь p, svg.lines p .15–.7, текст появляется p > .18, уходит p > .9.
- Pointer-параллакс (только мышь): .bgs ±16px, .bigword ∓10px, .flame-light ±6px (живой огонёк «тянется» к курсору).
- Все секции вне истории — на том же --bg; фото-секции получают градиенты 22vh в --bg через ::before/::after секции (НЕ mask на параллакс-картинке). Ни одной линии/рамки/смены фона между блоками.
- Для каждого кадра после генерации записать в site.js `FR[i] = {ox, oy, r}` (точка объекта в долях кадра): центр масок, transform-origin зума, позиция .flame-light. Для 04/05 дополнительно `NAILS = [{x,y,angle,len,w}×5]`, для 06 — `LASH = {x0,y0,x1,y1}` (линия роста ресниц).

---

## 3. Главы главной (hero + 8 глав = 9 кадров)
Доли P — от общей длины .story (1150vh).

### 0 · HERO — «nagels en lashes in kaarslicht.» (P .00–.07)
- **Кадр:** 01-candle-hero — соевая свеча в стеклянной баночке справа от центра, высокий спокойный огонёк, тёплая дымка над фитилём. Первый кадр истории.
- **Техника:** загрузка — из чёрного: сначала загорается только .flame-light (0→1, 600 ms, как зажжённая спичка), затем кадр проявляется (opacity + scale 1.08→1, 1.6 s), слова h1 выезжают по одному (70 ms). При скролле P 0–.06: текст hero растворяется вверх (translateY −40px, blur 0→6px), камера «ныряет» к пламени и ниже, в лужицу воска: .bgs scale 1→2.6, transform-origin = точка воска под фитилём (FR[0]).
- **Большое слово:** нет.
- **Текст:** чип «Nagel- & lashstudio · Kaatsheuvel»; h1 «nagels en lashes in kaarslicht.» (второе полустишие «in kaarslicht.» цветом --muted); lead — BIAB, gel, lashes en pedicure aan de Peperstraat, in alle rust, boeken via Treatwell. Кнопки: «Boek via Treatwell» (accent) + «Bekijk behandelingen» (ghost). Стеклянные плашки (только факты): «★ 4,9 · 127 reviews op Treatwell», «Ma–vr tot 20:00 · vr tot 21:00», «Gratis parkeren». Чип «Nu open · tot 20:00» (интерактив 3). Стеклянная полоса вкладок: Nagels / Lashes / Pedicure / Studio — подсветка бежит, клик = scrollTo главы 2 / 5 / 6 / 7.
- **Mobile:** кадр object-position по OX (~66%), свеча в верхних 50svh; h1 снизу на градиенте (≤5 строк на 360px, ≥44px); плашки горизонтальной лентой scroll-snap; вкладки скрыты.

### 1 · Kaarslicht — «eerst even landen.» (P .07–.18)
- **Кадр:** 02-wax-pool — макро: прозрачная лужица расплавленного соевого воска вокруг фитиля, в ней отражается пламя; у края баночки собирается одна густая молочная капля.
- **Техника — «тёплый bloom»:** продолжение зума hero; на scale 2.6 кадр 01 переходит в 02 через радиальную маску-«вспышку» из точки пламени (clip-path circle 0→150%, край размыт 40px через mask-image radial-gradient), в момент перехода .flame-light на 200 ms ярче (bloom). Поверх лужицы — «марево» (SVG feTurbulence + feDisplacementMap на копии верхних 30% кадра, baseFrequency анимируется, scale 6px; на mobile выключено). Капля у края — код: svg-эллипс ivory с бликом --accent, растёт по p .4–.9 (готовится сорваться).
- **Большое слово:** «rust»
- **Текст (3 абзаца, тема):** что гости отмечают в отзывах на Treatwell — расслабленная атмосфера, персональное внимание, соевые свечи (пересказ, без цитат); почему здесь не спешат: сначала сесть, согреть руки, рассказать, чего хочется; соевый воск горит мягко и спокойно — так и задуман визит. Факты-строка: «★ 4,9 op Treatwell · 127 reviews».
- **Mobile:** кадр 45svh сверху, текст-лист снизу (стеклянная карточка, 3-й абзац под «Lees meer»).

### 2 · De druppel — «één druppel. sterke nagels.» (P .18–.30)
- **Кадр:** 03-gel-drop — тонкая кисть для ногтей держится над баночкой, с неё срывается одна глянцевая капля молочно-нюдового BIAB-геля; позади — размытые огоньки свечей (боке).
- **Техника — «падение капли»:** svg-капля из главы 1 отрывается и падает вниз по скроллу (translateY привязан к p .0–.3, лёгкая деформация «вытягивание» scaleY 1→1.25); в точке, где она пересекает FR[3], кадр 02→03 сменяется концентрическими «кольцами ряби» (3 круга clip-path, задержка 80 ms, край размыт) — капля воска «становится» каплей геля. Затем на кадре 03 медленное «дыхание» капли: svg-блик скользит по капле сверху вниз (sheen, период 3.2 s).
- **Большое слово:** «biab»
- **Текст:** что такое BIAB (builder in a bottle) общими словами — гель, который укрепляет собственные ногти и даёт им расти, без обещаний; для кого (тонкие/ломкие ногти, хочется натурального вида). Цены (indicatief): BIAB nagels vanaf €40 (1u15–1u45) · Biab nieuwe set €50 (1u30) · Eigen nagels versteviging-gel €45 (was €55, 1u45) · BIAB verwijderen €20 (15 min). Ссылка «Alle prijzen» → behandelingen.html#nagels.
- **Mobile:** капля падает в пределах верхних 45svh; прайс — 4 строки списком.

### 3 · De nagel — «melkwit, als was.» (P .30–.43, интерактив 1)
- **Кадр:** 04-nails-nude — изящная кисть руки лежит на тёмном баклажановом бархате, короткие миндалевидные ногти в молочном nude BIAB, на каждом ногте тонкий оранжевый блик свечи; рядом на краю кадра — баночка-свеча (источник света).
- **Техника — «гель растекается»:** точка падения капли → по p .0–.28 из неё бегут 5 тонких светлых «нитей» (svg path, stroke-dashoffset) к пяти ногтям (NAILS); на каждом ногте кадр 04 проявляется через маску-эллипс по форме ногтя (svg mask: ellipse с rotate=angle, ry растёт от кутикулы к кончику), затем вся рука проявляется мягким кроссфейдом. По каждому ногтю проходит глянцевый sheen (linear-gradient ivory→accent, 45°, 1.4 s, по очереди мизинец→большой).
- **Большое слово:** «nude»
- **Текст:** почему молочный нюд и розовый — самые частые запросы; bijwerken: Biab bijwerken roze/nude €40 (1u15) · Biab roze/nude met iets verlenging €55 (1u45) · Biab bijwerken French/gellak kleur €45 (1u30); wanneer bijwerken vs nieuwe set (общими словами). **Интерактив 1 «Kies je finish»** встроен в панель (§5).
- **Mobile:** рука сверху 45svh; чузер — горизонтальные пилюли под кадром, цена/время крупно, кнопка Treatwell на всю ширину.

### 4 · Kleur — «kleur die blijft staan.» (P .43–.54)
- **Кадр:** 05-nails-aubergine — та же рука, та же поза, ногти — глубокий баклажановый гель-лак с зеркальным глянцем, в каждом ногте отражается огонёк свечи.
- **Техника — «заливка цветом»:** для каждого ногтя маска-полоса от кутикулы к кончику (svg mask rect вдоль оси ногтя, height 0→len), ногти «прокрашиваются» по очереди с задержкой 90 ms; в конце блик свечи «пробегает» по пяти ногтям слева направо (.flame-light скользит по точкам NAILS и задерживается на указательном).
- **Большое слово:** «kleur»
- **Текст:** gellak vs gel-nagels простыми словами; цены (indicatief): Gellak handen €40 (1u30) · Gel-nagels met verlenging vanaf €45 · Gel-nagels opvullen tot 4 weken €45 · Gel-nagels vernieuwen na 4 weken €55 · Nieuwe set gel-nagels €65 (2u15) · Nail art €10 · Kunstnagels reparatie €5 per nagel · Manicure €30 (1u) · Gellak verwijderen €15 · Biab/Gellak verwijderen ipv nieuwe set €10. Подаётся НЕ карточками, а «меню при свечах»: тонкие строки, точки-заполнители «········», цены прокрашиваются слева направо при входе.
- **Mobile:** меню — 6 строк + «Toon alles» (раскрывается).

### 5 · Lashes — «een waaier van licht.» (P .54–.67, интерактив 2)
- **Кадр:** 06-lashes-volume — макро закрытого глаза в 3/4 профиль (только веко, ресницы, бровь, кусочек скулы), пушистые Russian volume веера, на кончиках золотистый блик свечи. «Voorbeeldbeeld».
- **Техника — «блик улетает к глазу» + «веер»:** блик с указательного ногтя (гл. 4) вытягивается в тёплую диагональную полосу света (div 4px × 140vw, blur 18px, accent, screen), полоса проходит по экрану вверх-вправо; за ней кадр 05→06 меняется clip-path polygon, край которого следует за полосой. Затем вдоль LASH svg.lines рисует 9 пучков по 5–7 тонких лучей, которые раскрываются как веер (rotate от основания 0→±22°, stroke-dashoffset), задерживаются и гаснут — остаётся фото. Лёгкое мерцание блика на кончиках (flick).
- **Большое слово:** «lashes»
- **Текст:** wimperextensions, Russian volume (несколько тонких ресничек веером на одну свою), lash lift (подкручивание собственных); оценки на Treatwell: Eyelash Extensions 5,0 · Russian Volume 5,0 · Lash Lift 5,0. Цены не показаны → «Prijs op aanvraag — zie Treatwell». Абзац про бренды ресниц в работе (Magnitica Lashes, Noble Lashes — из BRIEF, без обещаний). Плюс строка «Ook: wenkbrauwen en gezicht harsen» (Eyebrow Waxing ★ 4,5 — эту оценку не выставлять как плашку, только в списке). **Интерактив 2 «Kies je lash-stijl»** (§5).
- **Mobile:** глаз сверху 40svh, веер-интерактив под ним (высота 30svh), текст ниже.

### 6 · Pedicure — «voeten omhoog.» (P .67–.78)
- **Кадр:** 07-pedicure-towel — elegant pedicured feet resting on a soft ivory towel (только стопы и щиколотки), ногти в баклажановом лаке, рядом 2–3 свечи в баночках, тёплый пар. «Voorbeeldbeeld».
- **Техника — «тёплая вода поднимается»:** кадр 06→07 через маску снизу вверх с волнистым краем (svg path, синусоида, фаза анимируется — край «плещется»), над краем — тонкая светящаяся линия ivory; canvas переключается в режим `steam`: мягкие ivory-клубы поднимаются вверх и тают (opacity .08–.18). Ken Burns медленно вниз (камера «садится» рядом).
- **Большое слово:** «pedicure»
- **Текст:** педикюр как пауза: тёплая вода, уход за ногами, по желанию цвет; на Treatwell 4 педикюр-процедуры vanaf €40 (названия не придумывать: «Kies op Treatwell welke pedicure bij je past»); оценка Pedicure ★ 4,9; удобно после работы — открыты до 20:00 (vr 21:00).
- **Mobile:** волна-маска та же, пар выключен при `saveData`/reduced-motion.

### 7 · De studio — «ontspannen. met aandacht.» (P .78–.89)
- **Кадр:** 08-studio-room — интерьер небольшой студии вечером: маникюрный столик с лампой, мягкое кресло, кушетка для ресниц с полотенцем, много соевых свечей в стеклянных баночках на полке и столике; никого нет.
- **Техника — «отъезд камеры»:** кадр 08 начинается с scale 2.2 с transform-origin на одной свече на столике (FR[8]) — кажется продолжением крупного плана; по p 0–.5 камера отъезжает к scale 1.0, кроссфейд 07→08 в первые 15%. Все огоньки в кадре мерцают: 5–7 маленьких .halo в координатах свечей (CANDLES[]), каждый со своей фазой flick; .flame-light «оседает» в одну из них.
- **Большое слово:** «aandacht»
- **Текст:** студия на Peperstraat 6A; персональное внимание, без конвейера; бренды, с которыми работает салон: Elan, Thuya, Magnitica Lashes, Noble Lashes, Mistero Milano, Slowianka, Julia Nessa, Apis (как тонкая бегущая строка имён внутри главы, только текст, без логотипов). Стеклянные плашки-факты: «★ 4,9 · 127 reviews», «Alleen contant», «Boeken via Treatwell». Ссылка «Over Avvenente» → over-ons.html.
- **Mobile:** отъезд камеры тот же, плашки лентой, строка брендов уменьшена.

### 8 · Peperstraat — «peperstraat 6a. tot zo.» (P .89–1.00)
- **Кадр:** 09-peperstraat-dusk — тихая улица голландской деревни в синий час, низкий кирпичный дом справа, одно окно первого этажа тёплое (свечи на подоконнике), влажная клинкерная мостовая отражает свет; без людей и читаемых вывесок.
- **Техника — «через окно наружу»:** обратная маска: кадр 09 появляется вокруг прямоугольника окна (WIN = {x,y,w,h}) — clip-path inset от размера окна до полного кадра, т.е. мы «выходим» из комнаты через окно на улицу; окно в 09 продолжает светиться (.glow-win, мерцание). Чип «Nu open?» живой. На P .95–1 вся сцена уходит в --bg (.story__fade), огонёк в окне гаснет последним.
- **Большое слово:** «kaatsheuvel»
- **Текст:** адрес Peperstraat 6A, Kaatsheuvel; часы ma–do 09:00–20:00, vr 09:00–21:00, za–zo gesloten; gratis parkeren, bushalte «Kaatsheuvel, Berndijksestraat»; alleen contant; telefoon volgt — boeken via Treatwell. Кнопки «Boek via Treatwell» (accent), «Route plannen» (ghost, Google Maps по координатам 51.6611788,5.0324886).
- **Mobile:** окно в верхней половине, адрес-блок стеклянной карточкой.

---

## 4. Секции главной после истории (все на --bg, без стыков)
1. **Бегущая строка фактов** проявляется из затемнения: «★ 4,9 op Treatwell · 127 reviews · BIAB vanaf €40 · lashes · pedicure · open tot 20:00 · vrijdag tot 21:00 · gratis parkeren · alleen contant · Peperstraat 6A». Red Hat Display 300, огромный, цвет --line, бесконечный ход, ускоряется от скорости скролла; разделитель — маленький огонёк --accent (svg-капля, flick).
2. **Кампания-разрыв «in jouw handen.»** — кадр 11-campaign-hands (4:5) справа с параллаксом data-par .18, слева h2 + 2 абзаца (что отличает визит: время, тишина, тёплый свет), «Voorbeeldbeeld». Движение: дымка, sheen по ногтям раз в 6 s, искры embers.
3. **«Wat gasten noemen»** — не отзывы, а 4 темы из отзывов Treatwell (пересказ): «ontspannen sfeer», «vriendelijk en kundig», «mooie lashes», «gelnagels en harsen netjes». Подача: слова огромные, по одному, «загораются» из --muted в --light по мере скролла (scroll-linked), рядом стеклянная плашка «★ 4,9 · 127 reviews — bron: Treatwell» + ссылка. Никаких выдуманных цитат.
4. **Кампания-разрыв «kijk maar.»** — кадр 12-campaign-lashes (4:5) слева, текст справа (зеркально к п.2): коротко про lashes + кнопка «Kies je lash-stijl» → behandelingen.html#lashes. «Voorbeeldbeeld». Движение: блик на кончиках ресниц, параллакс от мыши.
5. **Финал** — кадр 01-candle-hero возвращается (кольцо истории) с медленным наездом; огромный h2 «even helemaal ontspannen.», 2 кнопки (Boek via Treatwell / Route plannen); canvas `embers` плотнее + несколько «падающих» тёплых искр; огонёк реагирует на курсор (наклоняется в сторону мыши: skewX ±6° на svg-пламени поверх фото, мягко).
6. **Footer** — AVVENENTE (Red Hat Display 300, letter-spacing .3em) + «nail & lash studio», адрес, часы, «Nu open?», «Alleen contant · boeken via Treatwell», «Ontwerpvoorstel door ITty Company. Beelden zijn voorbeeldbeelden.»

Объём текста главной ≥ 900 слов NL (§10).

---

## 5. Нишевые интерактивы (цены только из BRIEF, подпись «indicatief — actuele prijzen op Treatwell»)

### Интерактив 1 · «Kies je finish» (глава 3; полная версия на behandelingen.html#nagels)
- Ряд 1 «Kleur» (role=radiogroup, свотчи-кружки): **Melkwit nude · Zacht roze · French · Kleur (gellak)**.
- Ряд 2 «Wat wil je?»: **Nieuwe set · Bijwerken · Met iets verlenging · Versteviging eigen nagels**.
- Ряд 3 опции (чекбоксы): **+ Nail art** (+15 min, +€10) · **+ Oude set eraf** («Biab/Gellak verwijderen ipv nieuwe set», +15 min, +€10).
- Матрица (из BRIEF):
  - Nieuwe set (любой цвет) → 1u30 · €50
  - Bijwerken + nude/roze → 1u15 · €40; Bijwerken + French/Kleur → 1u30 · €45
  - Met iets verlenging → только nude/roze: 1u45 · €55 (для French/Kleur пилюля disabled с подсказкой «alleen roze/nude»)
  - Versteviging eigen nagels (gel) → 1u45 · €45 (зачёркнуто €55)
  - Итог = база + опции; время суммируется («1u30 + 15 min = 1u45»).
- Визуал кодом на кадре 04/05: nude → кадр 04; roze → кадр 04 + svg-маски ногтей с заливкой rgba(232,170,170,.28) mix-blend:soft-light; French → кадр 04 + svg ivory-кончики (path по NAILS, 18% длины); Kleur → кросс-фейд на кадр 05. При смене — sheen-блик пробегает по ногтям; «Met iets verlenging» — ногти визуально удлиняются (svg-кончики +12% len, нюдовые, полупрозрачные).
- Справа крупно (stat-num, прокрутка цифр): цена, длительность; кнопка «Boek deze set» → Treatwell. Клавиатура ←/→, aria-live="polite" для цены.

### Интерактив 2 · «Kies je lash-stijl» (глава 5; повтор на behandelingen.html#lashes) — БЕЗ цен
- Сегменты: **Classic extensions · Russian volume · Lash lift**.
- Визуал на кадре 06 (svg вдоль LASH, 30–40 точек основания): Classic — одна тонкая линия на точку, ровная длина; Russian volume — веер 5–7 лучей на точку, мягкое «облако»; Lash lift — собственные короткие ресницы, линии плавно подкручиваются вверх (morph кривизны path). Перестройка 600 ms (stroke-dashoffset + rotate от основания), золотистая искра на кончике.
- Текст под каждым: что это, для кого, примерно как ощущается (общее о ремесле, без цифр стойкости); строка «★ 5,0 op Treatwell» (реальная средняя по каждой из трёх процедур); «Prijs op aanvraag — zie Treatwell»; кнопка «Bekijk op Treatwell».
- Доступность: role=radiogroup, ←/→, описание выбора в aria-live; reduced-motion — мгновенная смена.

### Интерактив 3 · «Nu open?» (hero-чип, глава 8, contact, footer)
- Часы: ma–do 09:00–20:00, vr 09:00–21:00, za–zo gesloten. Время — `Intl.DateTimeFormat('nl-NL',{timeZone:'Europe/Amsterdam',...})`.
- Состояния: «Nu open · tot 20:00» (вт) / «Nu open · tot 21:00» (vr) — точка --accent «горит» как огонёк (flick); «Sluit om 20:00» за 30 min до закрытия; «Gesloten · opent morgen 09:00»; «Gesloten · opent maandag 09:00» (vr вечер, za, zo); до 09:00 в будни — «Opent vandaag om 09:00».
- На contact.html — неделя из 7 строк, сегодняшняя подсвечена, тонкая «свеча-линия» времени идёт по шкале дня 07:00–22:00; в выходные свеча на шкале погашена (серый фитиль).

---

## 6. Внутренние страницы (каждая со своим кино-hero + своя движущая идея)
Общее: hero 100svh, фото справа/по центру, тёмная пустота слева под h1 (строчный, с точкой), чип, 2 кнопки, стеклянные плашки; снизу ::after градиент в --bg; слова h1 выезжают; canvas embers; .flame-light мерцает в точке свечи кадра; pointer-параллакс.

| Страница | Hero-кадр | h1 | Движущая идея | Содержание |
|---|---|---|---|---|
| **behandelingen.html** | 08-studio-room (object-position 64%) | «alles voor handen, voeten en lashes.» | **«Фитиль-линия»**: закреплённая горизонтальная тонкая линия (--line, 1px) с остановками **Nagels · Gel & gellak · Manicure · Pedicure · Lashes · Gezicht**; по скроллу огонёк (svg-пламя 14px, flick) едет по линии, активная остановка загорается, соответствующий блок прайса «прокрашивается» строками слева направо. Фоновые кропы для категорий — из 04/05/06/07 через object-position (новых картинок нет), меняются круглой волной из огонька. | Весь прайс BRIEF по группам (время + цена, «vanaf» где есть, зачёркнутое €55 у versteviging), интерактив 1 полностью, интерактив 2, pedicure «4 behandelingen vanaf €40 — zie Treatwell», lashes/gezicht «prijs op aanvraag». Плашка «Indicatief, 18.11.2026 — actuele prijzen op Treatwell». CTA Treatwell. |
| **over-ons.html** | 10-still-life (object-position 66%) | «klein. rustig. met aandacht.» | **Текст загорается от свечи**: манифест в 3 абзаца крупным Red Hat Display 300, слова переходят из --muted в --light с тёплым text-shadow (0 0 18px rgba(255,165,82,.25)) по мере скролла — как если бы свеча освещала строку; **бренды** — медленная бегущая строка имён (Elan · Thuya · Magnitica Lashes · Noble Lashes · Mistero Milano · Slowianka · Julia Nessa · Apis), при наведении имя подсвечивается. | Атмосфера (соевые свечи, расслабленность — из отзывов), подход (персональное внимание, без спешки), чем занимается студия (lashes, manicure, pedicure как специализация), рейтинги Treatwell (4,9 / 127; по услугам 5,0/5,0/5,0/4,9/4,5), кадр 11-campaign-hands («Voorbeeldbeeld»). Без имён, без лет работы, без происхождения владелицы. |
| **contact.html** | 09-peperstraat-dusk (object-position 70%) | «peperstraat 6a. kom binnen.» | **Окно «дышит»**: glow-win мерцает в такт времени (открыто — тёплое, ярче; закрыто — кадр filter brightness .78, окно тусклое, одна свеча); неделя «Nu open?» со свечой-линией времени. | Адрес, часы, Treatwell-кнопка, «Telefoon volgt» (плейсхолдер, без выдуманного номера), «Alleen contant», «Gratis parkeren», «Bushalte Kaatsheuvel, Berndijksestraat», «Route plannen» (ссылка Google Maps по координатам, без iframe). |

Mobile hero: кадр сверху (object-position по объекту), h1 снизу на градиенте, плашки лентой.

---

## 7. Переход между страницами — «вдох свечи»
- Шторка --bg (с лёгким вертикальным градиентом в --surface) въезжает снизу (вперёд по меню) / сверху (назад). Верхний край шторки — не прямая линия, а мягкая «восковая» кромка: svg-путь с 2–3 пологими наплывами и тонким ivory-бликом (как край застывшего воска), без рамок.
- По центру: svg-огонёк (капля пламени --accent + внутреннее ivory-ядро) загорается и мерцает; под ним «AVVENENTE» (Red Hat Display 300, letter-spacing .3em) и название целевой страницы строчными (--muted).
- Открытие: огонёк делает «вдох» — радиальное свечение из пламени расширяется до краёв (clip-path circle 0→150% на шторке в обратную сторону), открывая новую страницу; искры embers разлетаются.
- 650 ms закрытие → переход → открытие (как .curtain.in/.out в scena-piekna, `pageshow` для bfcache). reduced-motion: fade 150 ms.
- Направление по индексу меню: Home 0, Behandelingen 1, Over ons 2, Contact 3.

---

## 8. Картинки — ровно 12 (Higgsfield gpt_image_2_6)

### Общий якорь (вставлять в КАЖДЫЙ промпт дословно)
> **ANCHOR:** Cinematic premium beauty-campaign photograph, low-key studio lighting in a seamless deep aubergine darkness (#1A0B2A) with no visible horizon, the only warm light comes from a small soy-candle flame (#FFA552 candle-orange glow) placed low on the right, a soft ivory (#F5EEE4) rim light from the upper right to separate shapes, rich velvety shadows, warm haze, shallow depth of field, 85mm lens at eye level with a slight three-quarter angle, subtle film grain, calm luxurious relaxing mood, photorealistic, no text, no letters, no logos, no watermark.

Композиционные приставки:
- **COMP-R (16:9):** The subject sits right of centre at about 62% of the frame width and 50% height, filling about 45% of the frame height; the left 42% of the frame is empty dark aubergine negative space for a headline; identical framing and light to the reference image. Aspect ratio 16:9, 1536x864.
- **COMP-S (сцена, 16:9):** Wide atmospheric scene without people, the light and detail sit centre-right, the left third falls into deep aubergine shadow for text. Aspect ratio 16:9, 1536x864.
- **COMP-V (кампания, 4:5):** Vertical campaign crop, subject centred slightly right, generous dark space at the top for a short headline. Aspect ratio 4:5, 1024x1280. Clearly an AI campaign example image.

| # | Файл (assets/img/) | Формат | Референс | Где | Voorbeeldbeeld |
|---|---|---|---|---|---|
| 01 | 01-candle-hero.webp | 16:9 | — мастер-кадр | bg-0 hero, финал | — |
| 02 | 02-wax-pool.webp | 16:9 | 01 | bg-1 «rust» | — |
| 03 | 03-gel-drop.webp | 16:9 | 01 (свет) | bg-2 «biab» | — |
| 04 | 04-nails-nude.webp | 16:9 | 01 (свет) — мастер-кадр рук | bg-3 «nude», интерактив 1, кропы behandelingen | да (работа) |
| 05 | 05-nails-aubergine.webp | 16:9 | 04 | bg-4 «kleur», интерактив 1 | да |
| 06 | 06-lashes-volume.webp | 16:9 | 01 (свет) | bg-5 «lashes», интерактив 2 | да |
| 07 | 07-pedicure-towel.webp | 16:9 | 05 (цвет лака), 01 (свет) | bg-6 «pedicure» | да |
| 08 | 08-studio-room.webp | 16:9 | 01 | bg-7 «aandacht», hero behandelingen | — |
| 09 | 09-peperstraat-dusk.webp | 16:9 | 08 (свечи в окне) | bg-8 «kaatsheuvel», hero contact | — |
| 10 | 10-still-life.webp | 16:9 | 01, 05 | hero over-ons | — |
| 11 | 11-campaign-hands.webp | 4:5 | 04 | кампания «in jouw handen.», over-ons | да |
| 12 | 12-campaign-lashes.webp | 4:5 | 06 | кампания «kijk maar.» | да |

### Промпты (ANCHOR + приставка + текст)

**01 · 01-candle-hero** — ANCHOR + COMP-R +
A single soy candle in a short, thick clear-glass jar, creamy ivory wax with a softly melted surface, one calm tall teardrop flame glowing candle-orange, a thin ribbon of warm haze rising above the wick; the glass catches ivory rim highlights and warm orange reflections; the jar stands on an invisible dark aubergine surface that reflects a soft pool of orange light; a few tiny warm floating dust motes. 

**02 · 02-wax-pool** — ANCHOR + reference image 01 +
The camera has flown into the same candle from image 01: a macro close-up of the clear pool of melted soy wax around the black wick, the flame partly visible at the top edge of the frame and mirrored as a glowing orange reflection in the liquid wax; at the right rim of the glass jar a single thick, milky ivory drop of wax is forming and about to fall; the wax pool and jar fill the right 60% of the frame, the left 40% fades into dark aubergine shadow; same light direction and colours as the reference. Aspect ratio 16:9, 1536x864.

**03 · 03-gel-drop** — ANCHOR + COMP-R + light reference 01 +
A slim professional nail brush with a fine tapered tip held vertically in mid-air (no hand visible), a single glossy, milky nude-beige drop of builder gel falling from its tip and frozen in mid-fall, its surface reflecting a tiny candle flame and an ivory rim highlight; below it a small open glass gel jar; behind, out of focus, three or four soft orange candle bokeh circles in the aubergine darkness.

**04 · 04-nails-nude** — ANCHOR + COMP-R + light reference 01 +
An elegant relaxed female hand resting palm-down on dark aubergine velvet, fingers gently spread, only the hand and wrist visible, natural smooth skin, five short almond-shaped nails finished in milky nude BIAB gel with a flawless glassy gloss; each nail shows a thin candle-orange highlight; at the far right edge a softly blurred small soy candle in a glass jar provides the warm light. Clearly an AI campaign example image.

**05 · 05-nails-aubergine** — ANCHOR + COMP-R + reference image 04 (same hand, same pose, same framing) +
Identical hand, pose, velvet and candle as the reference, but the five almond nails are now finished in a deep glossy aubergine gel polish with a mirror-like shine, a small reflection of the candle flame visible on each nail as a warm orange highlight; everything else unchanged. Clearly an AI campaign example image.

**06 · 06-lashes-volume** — ANCHOR + COMP-R + light reference 01 +
Extreme macro close-up of a young woman's closed left eye in peaceful rest, three-quarter profile, only eyelid, lashes, a softly groomed natural eyebrow and a little cheekbone visible (no full face), smooth natural skin; elegant Russian volume lash extensions in soft dark fans, light and fluffy, gently curled; the candle light from below-right makes the lash tips glint warm gold-orange, an ivory rim light along the brow bone; the left 42% of the frame falls into deep aubergine shadow. Clearly an AI campaign example image.

**07 · 07-pedicure-towel** — ANCHOR + COMP-R + colour reference 05 (nail colour), light reference 01 +
Elegant pedicured feet resting on a soft folded ivory towel, seen from the side at a low angle, only feet and ankles visible, relaxed and calm; toenails in the same deep glossy aubergine polish with tiny candle-orange highlights; beside the towel two small soy candles in glass jars glowing, a gentle wisp of warm steam rising from a shallow dark bowl of water in the background; spa-like tranquillity. Clearly an AI campaign example image.

**08 · 08-studio-room** — ANCHOR + COMP-S + light reference 01 +
Interior of a small, cosy premium nail and lash studio in the evening: on the right a compact manicure table with a soft cushion and a slim desk lamp turned low, beside it a comfortable chair; in the centre a lash bed with a folded ivory towel; on a shelf and on the table many small soy candles in clear glass jars glowing candle-orange; walls and floor in deep matte aubergine, warm haze in the air; tidy, calm and spotless; no people.

**09 · 09-peperstraat-dusk** — ANCHOR + COMP-S + reference image 08 (candle glow) +
A quiet street in a small Dutch village at blue-hour dusk, the sky deep aubergine-violet: on the right a low red-brick house with white window frames, one ground-floor studio window glowing warm candle-orange with a row of small glass-jar candles on the windowsill and a soft ivory interior light behind them; the wet clinker-brick pavement reflects the orange window light; a little mist, a bare young tree; the left third falls into deep shadow; no people, no cars in focus, no readable signs, no house numbers.

**10 · 10-still-life** — ANCHOR + COMP-R + light reference 01, colour reference 05 +
A calm luxury still life on dark aubergine velvet: an open soy candle in a glass jar with a glowing flame on the right, around it a few unlabelled glass bottles of nail gel in milky nude and deep aubergine, a fine nail brush, slim steel lash tweezers and a small lash palette tile with neat rows of dark lash fans, a folded ivory cloth; warm orange reflections on glass and steel, ivory rim light; no labels, no brand names, no text.

**11 · 11-campaign-hands** — ANCHOR + COMP-V + reference image 04 (hand, nails) +
Two elegant female hands gently cupping a lit soy candle in a clear glass jar at chest height, only hands and wrists visible, short almond nails in milky nude BIAB with a glassy gloss, the candle flame lighting the fingers warmly from inside the cupped hands, soft ivory rim light on the knuckles, warm haze above the flame.

**12 · 12-campaign-lashes** — ANCHOR + COMP-V + reference image 06 (lashes, light) +
Vertical beauty-campaign crop showing only the upper half of a young woman's face from the bridge of the nose up, eyes softly open with a calm look slightly away from the camera, Russian volume lash extensions, natural groomed brows; a small candle flame out of focus in the lower right foreground casts a warm orange glow and tiny golden glints on the lash tips; the rest dissolves into aubergine shadow. Clearly an AI campaign example image.

Порядок генерации: 01 → 02, 08 → 09; 01 → 03; 01 → 04 → 05 → 07, 11; 01 → 06 → 12; 01 + 05 → 10. Если 05 «уплывает» по позе руки — перегенерировать от 04 тем же seed (иначе ломается маска NAILS). Безопасность фильтров: в людях — только руки/стопы до щиколотки/зона глаз; никаких других участков кожи.
Обработка: webp q78, 1920px по длинной стороне (mobile srcset 960px). Записать в site.js FR[i] (ox, oy), NAILS для 04/05 (одни и те же координаты!), LASH для 06, CANDLES для 08, WIN для 09.
В вёрстке на 04, 05, 06, 07, 11, 12 — чип «Voorbeeldbeeld» в углу кадра (12px, --muted, glass), alt-тексты описательные NL.

---

## 9. Движение по секциям (всё кодом; играет только когда видно; reduced-motion = статичные кадры с кроссфейдом)
| Секция | Движение |
|---|---|
| Загрузка | сначала загорается огонёк (.flame-light), затем кадр 01 из чёрного + scale 1.08→1; слова h1 выезжают; плашки плавают (float 6 s); блик по accent-кнопке |
| Hero | embers canvas, тёплая дымка над фитилём, flick пламени, pointer-параллакс; при скролле текст растворяется + зум в воск |
| 1 rust | bloom-маска из пламени, марево (feTurbulence), капля у края растёт |
| 2 biab | капля падает по скроллу, кольца ряби, sheen по капле геля |
| 3 nude | 5 светящихся нитей к ногтям, маски-эллипсы ногтей, sheen по очереди; чузер перерисовывает ногти |
| 4 kleur | ногти прокрашиваются от кутикулы к кончику, блик свечи бежит по ногтям; «меню» прокрашивается |
| 5 lashes | тёплая полоса света летит к глазу (маска за ней), веер ресниц раскрывается и гаснет, мерцание кончиков |
| 6 pedicure | волна тёплой воды снизу (плещущийся край), пар |
| 7 aandacht | отъезд камеры от одной свечи, все огоньки мерцают вразнобой, строка брендов |
| 8 kaatsheuvel | выход через окно (inset-маска), окно мерцает, затем fade в --bg |
| Бегущая строка | ход + ускорение от скролла, огоньки-разделители мерцают |
| Кампании ×2 | параллакс 4:5 кадров, sheen / блик на ресницах, дымка |
| «Wat gasten noemen» | слова загораются по скроллу |
| Финал | возврат кадра 01 с наездом, embers плотнее, пламя наклоняется к курсору |
| behandelingen | огонёк едет по фитиль-линии, круглая волна фоновых кропов, прайс прокрашивается, интерактивы 1–2 |
| over-ons | манифест загорается словами, бегущая строка брендов, параллакс натюрморта |
| contact | окно «дышит» по статусу открыто/закрыто, свеча-линия времени |
| Переход | шторка с восковой кромкой + огонёк + AVVENENTE, «вдох» открывает страницу |

Производительность: canvas DPR ≤ 2 (mobile ≤ 1.5), пауза вне экрана и во скрытой вкладке, кадры глав лениво на одну главу вперёд, feTurbulence только на десктопе; без WebGL (CSS / SVG / canvas2d).

## 10. Честность
Только факты BRIEF. Цены «indicatief (Treatwell, 18.11.2026) — actuele prijzen en boeken via Treatwell». Lashes и названия 4 педикюров — «prijs/keuze op Treatwell». Темы отзывов — пересказ, без цитат и имён. Без телефона/email/соцсетей («telefoon volgt»), без имён мастеров, лет работы, происхождения владелицы. Все ИИ-люди и «работы» — «Voorbeeldbeeld». Плашка «Ontwerpvoorstel door ITty Company».
