# BRIEF — AVVENENTE (Kaatsheuvel)

slug: avvenente
Ниша: nagel- & lashstudio (BIAB, gel-nagels, gellak, manicure, pedicure, wimperextensions, Russian volume, lash lift, gezichtsharsen/wenkbrauwen)
Адрес: Peperstraat 6A, Kaatsheuvel (postcode на источнике не указан). Координаты 51.6611788, 5.0324886.
ОV: bushalte «Kaatsheuvel, Berndijksestraat». Gratis parkeren.
Часы (Treatwell): ma–do 09:00–20:00, vr 09:00–21:00, za–zo gesloten.
Телефон / email / Instagram / Facebook: в открытых источниках НЕ найдены → на сайте запись через Treatwell, контакт-плейсхолдеры «telefoon volgt».
Оплата: alleen contant (cash only). Taal: Nederlands.
Рейтинг: ★ 4,9 op Treatwell (127 reviews). Средние по услугам на Treatwell: Eyelash Extensions 5,0 · Lash Lift 5,0 · Russian Volume 5,0 · Pedicure 4,9 · Eyebrow Waxing 4,5.
Описание (пересказ с Treatwell): салон известен персональным вниманием, расслабленной атмосферой и соевыми свечами. Специализация: lashes, manicure, pedicure. Работает с брендами: Elan, Thuya, Magnitica Lashes, Noble Lashes, Mistero Milano, Slowianka, Julia Nessa, Apis (часть брендов польские → возможно польскоязычная владелица — не утверждать на сайте).
Темы отзывов (пересказ, без цитат): расслабленная атмосфера, дружелюбный и умелый сервис, хорошая работа по ресницам, гель-ногтям и восковой эпиляции лица.

## Цены (Treatwell, 18.11.2026 — на сайте пометка «indicatief, zie Treatwell»)
- Biab/Gellak verwijderen ipv nieuwe set — 15 min — €10
- Gellak verwijderen — 15 min — €15
- BIAB nagels — 1u15–1u45 — vanaf €40
- Biab bijwerken roze/nude — 1u15 — €40
- Biab bijwerken French/gellak kleur — 1u30 — €45
- Biab nieuwe set — 1u30 — €50
- Biab roze/nude met iets verlenging — 1u45 — €55
- BIAB verwijderen — 15 min — €20
- Eigen nagels versteviging-gel — 1u45 — €45 (was €55)
- Gellak handen — 1u30 — €40
- Gel-nagels met verlenging — 1u45–2u15 — vanaf €45
- Gel-nagels opvullen tot 4 weken — 1u45 — €45
- Gel-nagels vernieuwen na 4 weken — 2u — €55
- Nieuwe set gel-nagels — 2u15 — €65
- Kunstnagels reparatie per nagel — 15 min — €5
- Manicure — 1u — €30
- Nail art — 15 min — €10
- Pedicure — 4 behandelingen, vanaf €40
- Lashes (extensions, Russian volume, lash lift) — цены на источнике не показаны → «prijs op aanvraag / zie Treatwell»

## Что плохо сейчас
Своего сайта и соцсетей в поиске нет — только карточка Treatwell. 127 отзывов 4,9 «спрятаны» на чужой платформе, в Google по запросу «nagelstudio Kaatsheuvel» салон не виден.

## Источники
- https://www.treatwell.nl/en/place/avvenente/
- WebSearch 18.11.2026 (своего сайта не найдено)

## Запреты
Не выдумывать отзывы, имена мастеров, телефон, Instagram, годы работы. Людей на AI-картинках подписывать «Voorbeeldbeeld». Без личных данных сотрудников.
