# TYPE — AVVENENTE

Формула ★ ГЛАВНЫЙ СТИЛЬ: тонкий геометрический гротеск 300 для огромного строчного заголовка с точкой,
плотный интерлиньяж; спокойный читаемый гротеск для текста. Без капса-постера, без скриптов.

## Пара
| Роль | Семейство | Веса | Почему |
|---|---|---|---|
| Display (h1–h3, цифры в стеклянных плашках) | **Red Hat Display** | 300 | Геометрия с мягким характером: круглые o/a, слегка сжатые пропорции, тонкий ровный штрих — в 300 выглядит как подпись дорогого бьюти-бренда, тонко, как линия ресницы. Отличается от уже использованных Urbanist/Sora/Outfit/Plus Jakarta/Jost: уже и «теплее», без tech-ощущения. |
| Text (абзацы, навигация, кнопки, чипы, цены) | **Instrument Sans** | 400 / 500 | Чёткий современный гротеск с открытыми формами, отлично читается на тёмном фоне в 17–19px на телефоне, табличные цифры для прайса. Не повторяет Figtree/Manrope/Albert Sans/Hanken Grotesk. |

Всего 3 начертания (Red Hat Display 300, Instrument Sans 400, 500). Курсив не грузим.

Проверено (curl css2 Google Fonts, 18.11.2026): оба семейства отдают сабсеты `latin` (U+0000–00FF: ë é ï ö ü €)
и `latin-ext` (U+0100–02BA и др.). Нидерландский (ë, ï, é, ĳ) покрыт полностью.

## Подключение
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Red+Hat+Display:wght@300&family=Instrument+Sans:wght@400;500&display=swap" rel="stylesheet">
```

```css
:root{
  --font-display:"Red Hat Display", "Century Gothic", system-ui, sans-serif;
  --font-text:"Instrument Sans", system-ui, -apple-system, "Segoe UI", sans-serif;
}
```

## Шкала
```css
body{
  font-family:var(--font-text); font-weight:400;
  font-size:clamp(17px, 0.35vw + 15.8px, 19px); line-height:1.6;
  color:var(--light); background:var(--bg);
  -webkit-font-smoothing:antialiased; text-rendering:optimizeLegibility;
}
h1,h2,h3,.display{ font-family:var(--font-display); font-weight:300; text-wrap:balance; }

h1{ font-size:clamp(48px, 8vw, 128px); line-height:.95; letter-spacing:-.03em; }        /* hero, 3–4 строки */
h2{ font-size:clamp(36px, 5vw, 76px);  line-height:1.0; letter-spacing:-.025em; }       /* заголовки секций */
h3{ font-size:clamp(24px, 2.4vw, 34px); line-height:1.15; letter-spacing:-.015em; }     /* карточки услуг, шаги */
.lead{ font-size:clamp(18px, 1.1vw + 12px, 22px); line-height:1.5; color:var(--muted); max-width:38ch; }
.stat-num{ font-family:var(--font-display); font-weight:300; font-size:clamp(32px, 3.2vw, 48px);
           line-height:1; letter-spacing:-.02em; font-variant-numeric:tabular-nums; }   /* «4,9», «127», «€40» */
.small, .caption{ font-size:14px; line-height:1.45; color:var(--muted); }
.chip{ font-family:var(--font-text); font-weight:500; font-size:13px; line-height:1;
       letter-spacing:.02em; }                                                          /* «Kaatsheuvel · Peperstraat», «★ 4,9 op Treatwell» */
.nav a, .btn{ font-family:var(--font-text); font-weight:500; font-size:15px; letter-spacing:.005em; }
.price{ font-weight:500; font-variant-numeric:tabular-nums; }
```

## Правила
1. **h1 — строчными, с точкой**, короткая фраза на 3–4 строки, слева на тёмном месте hero. Примеры:
   «nagels en lashes in kaarslicht.», «even helemaal ontspannen.», «zacht licht. sterke nagels.».
   Никакого `text-transform:uppercase` в заголовках.
2. **Red Hat Display только 300.** Не подменять жирным (600/700 не грузим → фальшивый bold). Акцент внутри
   заголовка — цветом `--muted` для второй половины фразы, не весом и не курсивом.
3. **Instrument Sans 400** — абзацы, описания услуг; **500** — навигация, кнопки, чипы, цены, названия процедур. 600+ не используем.
4. Логотип «AVVENENTE» — единственное место капса: Red Hat Display 300, `letter-spacing:.3em`, 15–18px; подпись
   «nail & lash studio» — Instrument Sans 400, строчными.
5. Чипы и подписи — обычный регистр, без капса; разрядка не больше .02em.
6. Цены и цифры — `tabular-nums`, единообразно «€40», «vanaf €45»; рейтинг с запятой по-нидерландски: «4,9».
7. Ширина текста: абзацы ≤ 62ch, lead ≤ 38ch, h1 ≤ 12ch (`max-width:12ch`), чтобы получались 3–4 строки.
8. Заголовки выезжают по словам: оборачивать слова в `<span>` (сплит по пробелам, не по символам — диакритика ë/é не ломается).
9. Акцентный цвет `--accent` в тексте не используется (только кнопка/иконки/свечение).
10. Мобильный 360px: h1 не больше 5 строк, иначе укоротить фразу, а не уменьшать кегль ниже 44px.
