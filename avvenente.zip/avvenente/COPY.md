# COPY — AVVENENTE (Kaatsheuvel)

Bron van alle feiten: BRIEF.md (Treatwell, 18.11.2026). Structuur en hoofdstukken: STORY.md. Taal: alleen Nederlands.

## Afspraken voor de builder
- Elke string heeft een sleutel: `common.*`, `home.*`, `beh.*`, `over.*`, `contact.*`. Sleutels zijn globaal uniek.
- Koppen: kleine letters, kort, met punt. Per woord splitsen voor de "woorden schuiven in"-animatie. Waar `|` staat: het deel na `|` krijgt kleur `--muted`.
- `{close}`, `{open}`, `{day}` = variabelen die site.js invult (STORY §5, interactief 3).
- Valuta: `€40`, tijden: `1u30`, `15 min`. Prijzen altijd met `common.price.note` in de buurt.
- Geen telefoonnummer, e-mail, Instagram, namen van medewerkers, jaartallen of herkomst. Geen citaten uit reviews: alleen thema's in eigen woorden, met bron Treatwell.
- Alle AI-beelden met mensen of "werk" (04, 05, 06, 07, 11, 12) krijgen `common.caption.ai`.

### Vaste links
- Boek via Treatwell → `https://www.treatwell.nl/en/place/avvenente/`
- Route plannen → `https://www.google.com/maps/dir/?api=1&destination=51.6611788,5.0324886`
- Reviews (bron) → `https://www.treatwell.nl/en/place/avvenente/`

---

# 0 · COMMON (alle pagina's)

## Navigatie
- `common.nav.home` — Home
- `common.nav.behandelingen` — Behandelingen
- `common.nav.over` — Over ons
- `common.nav.contact` — Contact
- `common.nav.book` — Boek via Treatwell *(witte pil-knop rechts in de nav)*
- `common.nav.menu` — Menu
- `common.nav.close` — Sluiten
- `common.nav.skip` — Naar de inhoud
- `common.logo` — AVVENENTE
- `common.logo.sub` — nail & lash studio

## Knoppen (CTA)
- `common.cta.book` — Boek via Treatwell
- `common.cta.bookSet` — Boek deze set
- `common.cta.bookLash` — Bekijk op Treatwell
- `common.cta.route` — Route plannen
- `common.cta.treatments` — Bekijk behandelingen
- `common.cta.allPrices` — Alle prijzen
- `common.cta.about` — Over Avvenente
- `common.cta.contact` — Adres & openingstijden
- `common.cta.reviews` — Lees de reviews op Treatwell

## Labels & kleine regels
- `common.price.note` — indicatief — actuele prijzen op Treatwell
- `common.price.noteDate` — Indicatief, 18.11.2026 — actuele prijzen en boeken via Treatwell
- `common.price.from` — vanaf
- `common.price.was` — was
- `common.price.ask` — Prijs op aanvraag — zie Treatwell
- `common.caption.ai` — Voorbeeldbeeld
- `common.source.treatwell` — bron: Treatwell
- `common.readmore` — Lees meer
- `common.readless` — Minder
- `common.showall` — Toon alles
- `common.showless` — Toon minder
- `common.rail.chapter` — Hoofdstuk {n} van 8
- `common.scroll` — scroll
- `common.cash` — Alleen contant
- `common.parking` — Gratis parkeren
- `common.phone` — Telefoon volgt
- `common.bookingNote` — Afspraak maken gaat via Treatwell

## Openingstijden ("Nu open?", interactief 3)
- `common.open.now` — Nu open · tot {close}
- `common.open.closingSoon` — Sluit om {close}
- `common.open.laterToday` — Opent vandaag om 09:00
- `common.open.tomorrow` — Gesloten · opent morgen 09:00
- `common.open.monday` — Gesloten · opent maandag 09:00
- `common.open.ask` — Nu open?
- `common.hours.mon` — maandag · 09:00–20:00
- `common.hours.tue` — dinsdag · 09:00–20:00
- `common.hours.wed` — woensdag · 09:00–20:00
- `common.hours.thu` — donderdag · 09:00–20:00
- `common.hours.fri` — vrijdag · 09:00–21:00
- `common.hours.sat` — zaterdag · gesloten
- `common.hours.sun` — zondag · gesloten
- `common.hours.short` — ma–do 09:00–20:00 · vr 09:00–21:00 · za–zo gesloten
- `common.hours.today` — vandaag

## Paginaovergang (curtain)
- `common.curtain.home` — home
- `common.curtain.behandelingen` — behandelingen
- `common.curtain.over` — over ons
- `common.curtain.contact` — contact

## Footer
- `common.footer.brand` — AVVENENTE
- `common.footer.sub` — nail & lash studio
- `common.footer.address` — Peperstraat 6A, Kaatsheuvel
- `common.footer.hours` — ma–do 09:00–20:00 · vr 09:00–21:00 · za–zo gesloten
- `common.footer.pay` — Alleen contant · boeken via Treatwell
- `common.footer.parking` — Gratis parkeren · bushalte Kaatsheuvel, Berndijksestraat
- `common.footer.phone` — Telefoon volgt
- `common.footer.rating` — ★ 4,9 op Treatwell · 127 reviews
- `common.footer.proposal` — Ontwerpvoorstel — ITty Company
- `common.footer.images` — Beelden met mensen en behandelresultaten zijn voorbeeldbeelden (Voorbeeldbeeld), geen werk van de studio.
- `common.footer.prices` — Prijzen indicatief (Treatwell, 18.11.2026).

---

# 1 · HOME (index.html)

## Meta
- `home.meta.title` — Avvenente · nagels en lashes in Kaatsheuvel
- `home.meta.desc` — Nagel- en lashstudio aan de Peperstraat 6A in Kaatsheuvel. BIAB, gel-nagels, gellak, manicure, pedicure, wimperextensions en lash lift. ★ 4,9 op Treatwell (127 reviews). Boek via Treatwell.

## 0 · Hero
- `home.hero.chip` — Nagel- & lashstudio · Kaatsheuvel
- `home.hero.h1` — nagels en lashes | in kaarslicht.
- `home.hero.lead` — BIAB, gel, gellak, lashes en pedicure aan de Peperstraat in Kaatsheuvel. Een kleine studio waar soja­kaarsen branden en niemand op de klok kijkt. Je kiest je behandeling en tijd op Treatwell, wij zorgen voor de rust.
- `home.hero.btn1` — Boek via Treatwell
- `home.hero.btn2` — Bekijk behandelingen
- `home.hero.stat1.num` — ★ 4,9
- `home.hero.stat1.label` — 127 reviews op Treatwell
- `home.hero.stat2.num` — tot 20:00
- `home.hero.stat2.label` — ma–do · vrijdag tot 21:00
- `home.hero.stat3.num` — gratis
- `home.hero.stat3.label` — parkeren bij de studio
- `home.hero.open` — Nu open · tot {close} *(live, interactief 3)*
- `home.hero.tabs.nails` — Nagels
- `home.hero.tabs.lashes` — Lashes
- `home.hero.tabs.pedicure` — Pedicure
- `home.hero.tabs.studio` — Studio
- `home.hero.scroll` — scroll en volg het licht

## Hoofdstuk 1 · Kaarslicht — bigword «rust»
- `home.ch1.kicker` — Hoofdstuk 1 van 8 · Kaarslicht
- `home.ch1.h2` — eerst even landen.
- `home.ch1.p1` — Wie bij Avvenente binnenstapt, merkt het meteen: het licht is zacht, het is stil, en ergens brandt een sojakaars. In de reviews op Treatwell komt die ontspannen sfeer steeds terug, net als de persoonlijke aandacht. Dat is geen toeval. Hier wordt gewerkt op afspraak, zodat er tijd is voor jou en niet voor de volgende in de rij.
- `home.ch1.p2` — Een afspraak begint hier niet met een vijl, maar met even zitten. Jas uit, handen warm, en vertellen wat je wilt. Naturel of juist kleur, kort of iets langer, alleen bijwerken of helemaal opnieuw. Pas als dat helder is, gaat de lamp aan. Zo weet je vooraf waar je aan toe bent en loop je straks niet verrast naar buiten.
- `home.ch1.p3` — Sojawas brandt rustig en langzaam, met een kleine, kalme vlam. Zo is ook het bezoek bedoeld: geen haast, geen gepraat over je hoofd heen, gewoon een uur of twee voor jezelf. Wil je na je werk, op een doordeweekse avond? Dat kan, want de studio is van maandag tot en met donderdag open tot acht uur.
- `home.ch1.fact1` — ★ 4,9 op Treatwell · 127 reviews
- `home.ch1.fact2` — Sojakaarsen in de studio
- `home.ch1.fact3` — Ma–do open tot 20:00

## Hoofdstuk 2 · De druppel — bigword «biab»
- `home.ch2.kicker` — Hoofdstuk 2 van 8 · BIAB
- `home.ch2.h2` — één druppel. | sterke nagels.
- `home.ch2.p1` — BIAB staat voor builder in a bottle: een stevige gel die over je eigen nagel wordt aangebracht. Geen kunstnagel eroverheen, maar een laag die je natuurlijke nagel steun geeft. Voor wie dunne of snel scheurende nagels heeft en toch een verzorgde, natuurlijke look wil, is het vaak de eerste stap. Het resultaat oogt glad, glanzend en rustig.
- `home.ch2.p2` — Een nieuwe set duurt ongeveer anderhalf uur. Je nagels worden netjes voorbereid, de gel wordt in dunne lagen opgebouwd en uitgehard, en daarna in vorm gebracht. Wil je liever alleen je eigen nagels verstevigen met gel? Ook dat kan, als aparte behandeling. En als het tijd is om te stoppen, wordt de BIAB zorgvuldig verwijderd.
- `home.ch2.fact1` — BIAB nagels vanaf €40 · 1u15–1u45
- `home.ch2.fact2` — Biab nieuwe set €50 · 1u30
- `home.ch2.fact3` — Eigen nagels versteviging-gel €45 (was €55) · 1u45
- `home.ch2.fact4` — BIAB verwijderen €20 · 15 min
- `home.ch2.note` — indicatief — actuele prijzen op Treatwell
- `home.ch2.link` — Alle prijzen

## Hoofdstuk 3 · De nagel — bigword «nude» (interactief 1)
- `home.ch3.kicker` — Hoofdstuk 3 van 8 · Nude & roze
- `home.ch3.h2` — melkwit, | als was.
- `home.ch3.p1` — Melkwit, zacht roze, een vleugje nude: het zijn de kleuren die bij BIAB het vaakst gekozen worden, en niet voor niets. Ze passen bij werk en weekend, bij een trouwfeest en bij de supermarkt. Ze laten je handen verzorgd ogen zonder dat iemand meteen ziet wat er gedaan is. En als je nagel uitgroeit, valt het randje nauwelijks op.
- `home.ch3.p2` — Na een paar weken groeit je eigen nagel door en ontstaat er ruimte bij de nagelriem. Dan kies je voor bijwerken: de bestaande laag wordt bijgevijld en aangevuld, zodat je weer strak zit. Wil je een andere kleur of is de set echt op, dan is een nieuwe set logischer. Twijfel je, overleg het gewoon aan tafel.
- `home.ch3.p3` — Zin in iets meer lengte? Bij roze en nude kan de nagel een klein stukje verlengd worden, zonder dat het een kunstnagel-look krijgt. French of een gellak-kleur bijwerken kan ook, dat kost wat meer tijd. Hieronder stel je je eigen set samen en zie je meteen de indicatieve prijs en duur.
- `home.ch3.fact1` — Biab bijwerken roze/nude €40 · 1u15
- `home.ch3.fact2` — Biab roze/nude met iets verlenging €55 · 1u45
- `home.ch3.fact3` — Biab bijwerken French/gellak kleur €45 · 1u30

### Interactief 1 · «Kies je finish»
- `home.finish.title` — kies je finish.
- `home.finish.intro` — Kies een kleur, wat je wilt en eventuele extra's. Je ziet direct de indicatieve prijs en hoe lang je ongeveer zit.
- `home.finish.row1` — Kleur
- `home.finish.color.nude` — Melkwit nude
- `home.finish.color.roze` — Zacht roze
- `home.finish.color.french` — French
- `home.finish.color.kleur` — Kleur (gellak)
- `home.finish.row2` — Wat wil je?
- `home.finish.type.new` — Nieuwe set
- `home.finish.type.fill` — Bijwerken
- `home.finish.type.ext` — Met iets verlenging
- `home.finish.type.strong` — Versteviging eigen nagels
- `home.finish.row3` — Extra's
- `home.finish.opt.art` — + Nail art (+15 min, +€10)
- `home.finish.opt.off` — + Oude set eraf (+15 min, +€10)
- `home.finish.disabled` — alleen bij roze/nude
- `home.finish.price` — Prijs
- `home.finish.time` — Duur
- `home.finish.sum` — {base} + {extra} = {total}
- `home.finish.was` — was €55
- `home.finish.note` — indicatief — actuele prijzen op Treatwell
- `home.finish.cta` — Boek deze set
- `home.finish.live` — {color}, {type}: {price}, ongeveer {time}

## Hoofdstuk 4 · Kleur — bigword «kleur»
- `home.ch4.kicker` — Hoofdstuk 4 van 8 · Gel & gellak
- `home.ch4.h2` — kleur die | blijft staan.
- `home.ch4.p1` — Gellak en gel-nagels klinken bijna hetzelfde, maar zijn het niet. Gellak is een dunne, glanzende kleurlaag op je eigen nagel: snel, strak en vrolijk. Gel-nagels zijn steviger en kunnen verlengd worden, voor wie een andere vorm of lengte wil. Allebei worden ze onder de lamp uitgehard, dus je loopt meteen droog en glanzend naar buiten.
- `home.ch4.p2` — Bij gel-nagels hoort onderhoud. Binnen vier weken wordt de set opgevuld, zodat de uitgroei weer gelijk loopt. Laat je het langer gaan, dan wordt de set vernieuwd. Een nagel afgebroken? Die wordt los gerepareerd. En wie liever helemaal klassiek gaat, boekt een manicure: vijlen, nagelriemen, verzorging, zonder gel.
- `home.ch4.p3` — Voor een klein accent is er nail art, voor de afwerking van je eigen ontwerp of kleur. Ga je over van gellak of BIAB naar een nieuwe set, dan wordt de oude laag eerst verwijderd. Het complete menu met tijden staat hieronder, en nog uitgebreider op de pagina Behandelingen.
- `home.ch4.menu.title` — het menu, bij kaarslicht.
- `home.ch4.menu.1` — Gellak handen · 1u30 · €40
- `home.ch4.menu.2` — Gel-nagels met verlenging · 1u45–2u15 · vanaf €45
- `home.ch4.menu.3` — Gel-nagels opvullen tot 4 weken · 1u45 · €45
- `home.ch4.menu.4` — Gel-nagels vernieuwen na 4 weken · 2u · €55
- `home.ch4.menu.5` — Nieuwe set gel-nagels · 2u15 · €65
- `home.ch4.menu.6` — Manicure · 1u · €30
- `home.ch4.menu.7` — Nail art · 15 min · €10
- `home.ch4.menu.8` — Kunstnagels reparatie per nagel · 15 min · €5
- `home.ch4.menu.9` — Gellak verwijderen · 15 min · €15
- `home.ch4.menu.10` — Biab/Gellak verwijderen ipv nieuwe set · 15 min · €10
- `home.ch4.note` — indicatief — actuele prijzen op Treatwell
- `home.ch4.link` — Alle prijzen

## Hoofdstuk 5 · Lashes — bigword «lashes» (interactief 2)
- `home.ch5.kicker` — Hoofdstuk 5 van 8 · Lashes
- `home.ch5.h2` — een waaier | van licht.
- `home.ch5.p1` — Lashes zijn een van de specialiteiten van de studio, en dat zie je terug op Treatwell: wimperextensions, Russian volume en lash lift krijgen daar alle drie gemiddeld een 5,0. Je ligt tijdens de behandeling met je ogen dicht, in een rustige ruimte. Juist daarom past een lashbehandeling zo goed bij deze rustige plek.
- `home.ch5.p2` — Bij classic extensions komt er op elk eigen wimpertje één extension: een natuurlijke, iets vollere lijn. Bij Russian volume worden meerdere superdunne extensions als een klein waaiertje op één wimper gezet, voor een zachte, donzige volheid. Een lash lift werkt juist met je eigen wimpers: die worden opgekruld, zodat ze langer en opener ogen, zonder extensions.
- `home.ch5.p3` — In de studio wordt gewerkt met onder meer Magnitica Lashes en Noble Lashes. Welke stijl bij jouw ogen past, bespreek je ter plekke. De prijzen van lashbehandelingen staan op Treatwell, daar kies je ook direct een moment. Ook voor wenkbrauwen en gezicht harsen kun je terecht.
- `home.ch5.fact1` — Eyelash Extensions ★ 5,0 op Treatwell
- `home.ch5.fact2` — Russian Volume ★ 5,0 op Treatwell
- `home.ch5.fact3` — Lash Lift ★ 5,0 op Treatwell
- `home.ch5.price` — Prijs op aanvraag — zie Treatwell
- `home.ch5.extra` — Ook: wenkbrauwen en gezicht harsen

### Interactief 2 · «Kies je lash-stijl» (zonder prijzen)
- `home.lash.title` — kies je lash-stijl.
- `home.lash.opt.classic` — Classic extensions
- `home.lash.opt.volume` — Russian volume
- `home.lash.opt.lift` — Lash lift
- `home.lash.classic.text` — Eén extension per eigen wimper. Een strakke, natuurlijke lijn die je ogen iets meer definitie geeft. Fijn als je wilt dat het mooi is, maar niet opvalt dat er iets gedaan is.
- `home.lash.volume.text` — Meerdere superdunne extensions als waaiertje op één wimper. Voller, zachter en donzig, zonder zwaar te ogen. Voor wie van een uitgesproken, maar zachte look houdt.
- `home.lash.lift.text` — Geen extensions: je eigen wimpers worden vanaf de basis opgekruld. Ze ogen langer en je blik wordt opener. Voor wie het natuurlijk wil houden en geen onderhoud aan extensions wil.
- `home.lash.rating` — ★ 5,0 op Treatwell
- `home.lash.price` — Prijs op aanvraag — zie Treatwell
- `home.lash.cta` — Bekijk op Treatwell
- `home.lash.live` — Gekozen: {style}

## Hoofdstuk 6 · Pedicure — bigword «pedicure»
- `home.ch6.kicker` — Hoofdstuk 6 van 8 · Pedicure
- `home.ch6.h2` — voeten omhoog.
- `home.ch6.p1` — Je voeten dragen je de hele dag, en meestal krijgen ze de minste aandacht. Een pedicure is daarom meer dan een likje lak: het is een pauze. Voeten in warm water, nagels netjes geknipt en gevijld, eelt en nagelriemen verzorgd, en daarna even niets. Wie wil, sluit af met kleur, zodat de sandalen weer uit de kast kunnen.
- `home.ch6.p2` — Op Treatwell staan vier pedicurebehandelingen, vanaf €40. Kies daar welke het beste bij je past, van een verzorgende behandeling tot een variant met kleur. De beoordeling van gasten voor pedicure: gemiddeld een 4,9. Handig is dat het ook na je werk kan, want doordeweeks is de studio open tot 20:00 en op vrijdag tot 21:00.
- `home.ch6.fact1` — Pedicure · 4 behandelingen · vanaf €40
- `home.ch6.fact2` — Pedicure ★ 4,9 op Treatwell
- `home.ch6.fact3` — Ma–do tot 20:00 · vr tot 21:00
- `home.ch6.link` — Kies op Treatwell welke pedicure bij je past

## Hoofdstuk 7 · De studio — bigword «aandacht»
- `home.ch7.kicker` — Hoofdstuk 7 van 8 · De studio
- `home.ch7.h2` — ontspannen. | met aandacht.
- `home.ch7.p1` — Aan de Peperstraat 6A in Kaatsheuvel zit een studio waar sojakaarsen branden en het tempo laag ligt. Geen lopende band, geen haast tussen twee klanten door. Je hebt je eigen moment en de aandacht blijft bij jou. Gasten op Treatwell noemen de service vriendelijk en kundig, en dat is precies waar het hier om draait.
- `home.ch7.p2` — Er wordt gewerkt met merken die in de nagel- en lashwereld bekendstaan, voor gel, verzorging en wimpers. Kwaliteit van materiaal zie je niet direct, maar je merkt het weken later nog. Betalen gaat contant, dus neem even cash mee. Afspraak maken doe je online via Treatwell, waar je ook de vrije tijden ziet.
- `home.ch7.brands` — Elan · Thuya · Magnitica Lashes · Noble Lashes · Mistero Milano · Slowianka · Julia Nessa · Apis
- `home.ch7.fact1` — ★ 4,9 · 127 reviews
- `home.ch7.fact2` — Alleen contant
- `home.ch7.fact3` — Boeken via Treatwell
- `home.ch7.link` — Over Avvenente

## Hoofdstuk 8 · Peperstraat — bigword «kaatsheuvel»
- `home.ch8.kicker` — Hoofdstuk 8 van 8 · Peperstraat
- `home.ch8.h2` — peperstraat 6a. | tot zo.
- `home.ch8.p1` — Je vindt Avvenente aan de Peperstraat 6A in Kaatsheuvel. Parkeren is gratis, dus je hoeft niet te zoeken of te rekenen. Kom je met de bus, stap dan uit bij halte Kaatsheuvel, Berndijksestraat. Plan je route vooraf met de knop hieronder, dan sta je zonder zoeken voor de deur van nummer 6A.
- `home.ch8.p2` — Open van maandag tot en met donderdag van 09:00 tot 20:00, op vrijdag van 09:00 tot 21:00. Op zaterdag en zondag is de studio dicht. Een telefoonnummer volgt nog; boeken gaat nu via Treatwell. Daar zie je direct welke tijden vrij zijn. Vergeet niet: betalen kan alleen contant.
- `home.ch8.fact1` — Peperstraat 6A, Kaatsheuvel
- `home.ch8.fact2` — Gratis parkeren · bushalte Berndijksestraat
- `home.ch8.fact3` — Alleen contant
- `home.ch8.fact4` — Telefoon volgt
- `home.ch8.open` — Nu open?
- `home.ch8.btn1` — Boek via Treatwell
- `home.ch8.btn2` — Route plannen

## Na de story

### Marquee (bigline, scheiding = vlammetje)
- `home.marquee` — ★ 4,9 op Treatwell · 127 reviews · BIAB vanaf €40 · lashes · pedicure · open tot 20:00 · vrijdag tot 21:00 · gratis parkeren · alleen contant · Peperstraat 6A

### Campagne 1 · beeld 11 rechts
- `home.camp1.h2` — in jouw | handen.
- `home.camp1.p1` — Een goede behandeling begint lang voordat de gel op je nagel komt. Met tijd om te vertellen wat je wilt, met een rustige tafel en licht dat niet in je ogen schijnt. Dat is het verschil tussen snel even je nagels laten doen en echt een moment voor jezelf nemen.
- `home.camp1.p2` — Bij Avvenente draait het niet om zoveel mogelijk afspraken op een dag. Er brandt een kaars, je handen liggen warm, en wat je mee naar huis neemt is meer dan een mooie set. Het is een uur waarin je even niets hoefde.
- `home.camp1.caption` — Voorbeeldbeeld

### Wat gasten noemen (thema's uit reviews, geen citaten)
- `home.themes.kicker` — Uit de reviews op Treatwell
- `home.themes.h2` — wat gasten noemen.
- `home.themes.intro` — Geen losse quotes, wel de rode draad. Dit zijn de onderwerpen die in de reviews op Treatwell steeds terugkomen, in onze eigen woorden samengevat.
- `home.themes.1.word` — ontspannen sfeer
- `home.themes.1.text` — Gasten noemen de rustige, relaxte sfeer in de studio, met de sojakaarsen als vast detail.
- `home.themes.2.word` — vriendelijk en kundig
- `home.themes.2.text` — De service wordt omschreven als vriendelijk en vakkundig, met persoonlijke aandacht.
- `home.themes.3.word` — mooie lashes
- `home.themes.3.text` — Het lashwerk wordt vaak genoemd: extensions, Russian volume en lash lift scoren gemiddeld een 5,0.
- `home.themes.4.word` — gelnagels en harsen netjes
- `home.themes.4.text` — Ook gel-nagels en het harsen van het gezicht komen terug als netjes uitgevoerd.
- `home.themes.badge` — ★ 4,9 · 127 reviews — bron: Treatwell
- `home.themes.link` — Lees de reviews op Treatwell

### Campagne 2 · beeld 12 links
- `home.camp2.h2` — kijk maar.
- `home.camp2.p1` — Classic voor een strakke lijn, Russian volume voor zachte, donzige volheid, of een lash lift voor je eigen wimpers. Alle drie scoren op Treatwell gemiddeld een 5,0. Welke stijl bij jouw ogen past, ontdek je in de kiezer of bespreek je gewoon in de studio.
- `home.camp2.btn` — Kies je lash-stijl
- `home.camp2.caption` — Voorbeeldbeeld

### Finale
- `home.final.kicker` — Peperstraat 6A · Kaatsheuvel
- `home.final.h2` — even helemaal | ontspannen.
- `home.final.p` — Kies je behandeling en een moment dat jou past. De kaars brandt al.
- `home.final.btn1` — Boek via Treatwell
- `home.final.btn2` — Route plannen
- `home.final.small` — Alleen contant · gratis parkeren · ma–do tot 20:00, vr tot 21:00

---

# 2 · BEHANDELINGEN (behandelingen.html)

## Meta
- `beh.meta.title` — Behandelingen & prijzen · Avvenente Kaatsheuvel
- `beh.meta.desc` — Alle behandelingen van Avvenente: BIAB, gel-nagels, gellak, manicure, nail art, pedicure, lashes en gezicht harsen. Indicatieve prijzen, boeken via Treatwell.

## Hero
- `beh.hero.chip` — Behandelingen · prijzen indicatief
- `beh.hero.h1` — alles voor handen, | voeten en lashes.
- `beh.hero.lead` — Van een snelle reparatie van één nagel tot een complete nieuwe set, van pedicure tot Russian volume. Hieronder staan alle behandelingen met duur en indicatieve prijs. Boeken en de actuele prijzen vind je op Treatwell.
- `beh.hero.btn1` — Boek via Treatwell
- `beh.hero.btn2` — Kies je finish
- `beh.hero.stat1` — ★ 4,9 · 127 reviews op Treatwell
- `beh.hero.stat2` — BIAB vanaf €40
- `beh.hero.stat3` — Alleen contant

## Wick-line (stops)
- `beh.stop.nagels` — Nagels
- `beh.stop.gel` — Gel & gellak
- `beh.stop.manicure` — Manicure
- `beh.stop.pedicure` — Pedicure
- `beh.stop.lashes` — Lashes
- `beh.stop.gezicht` — Gezicht

## Prijsnotitie
- `beh.note` — Indicatief, 18.11.2026 — actuele prijzen en boeken via Treatwell

## Nagels · BIAB (#nagels)
- `beh.nagels.h2` — biab.
- `beh.nagels.p` — Builder gel over je eigen nagel: steun voor dunne of zwakke nagels en een natuurlijke, glanzende look. Kies een nieuwe set, laat bijwerken, of ga voor iets meer lengte bij roze en nude.
- `beh.nagels.1` — BIAB nagels · 1u15–1u45 · vanaf €40
- `beh.nagels.2` — Biab nieuwe set · 1u30 · €50
- `beh.nagels.3` — Biab bijwerken roze/nude · 1u15 · €40
- `beh.nagels.4` — Biab bijwerken French/gellak kleur · 1u30 · €45
- `beh.nagels.5` — Biab roze/nude met iets verlenging · 1u45 · €55
- `beh.nagels.6` — Eigen nagels versteviging-gel · 1u45 · €45 *(was €55)*
- `beh.nagels.7` — BIAB verwijderen · 15 min · €20
- `beh.nagels.8` — Biab/Gellak verwijderen ipv nieuwe set · 15 min · €10
- *(Interactief 1 volledig hier — zelfde sleutels als `home.finish.*`)*

## Gel & gellak (#gel)
- `beh.gel.h2` — gel & gellak.
- `beh.gel.p` — Gellak is een glanzende kleurlaag op je eigen nagel. Gel-nagels zijn steviger en kunnen verlengd worden. Gel-nagels vul je binnen vier weken op; daarna wordt de set vernieuwd.
- `beh.gel.1` — Gellak handen · 1u30 · €40
- `beh.gel.2` — Gel-nagels met verlenging · 1u45–2u15 · vanaf €45
- `beh.gel.3` — Gel-nagels opvullen tot 4 weken · 1u45 · €45
- `beh.gel.4` — Gel-nagels vernieuwen na 4 weken · 2u · €55
- `beh.gel.5` — Nieuwe set gel-nagels · 2u15 · €65
- `beh.gel.6` — Kunstnagels reparatie per nagel · 15 min · €5
- `beh.gel.7` — Gellak verwijderen · 15 min · €15

## Manicure (#manicure)
- `beh.mani.h2` — manicure & nail art.
- `beh.mani.p` — Klassieke verzorging van je handen en nagels, zonder gel. En voor een klein accent op je set: nail art.
- `beh.mani.1` — Manicure · 1u · €30
- `beh.mani.2` — Nail art · 15 min · €10

## Pedicure (#pedicure)
- `beh.pedi.h2` — pedicure.
- `beh.pedi.p` — Een pauze voor je voeten: verzorging van nagels en huid, en wie wil sluit af met kleur. Op Treatwell staan vier pedicurebehandelingen; daar kies je welke bij je past.
- `beh.pedi.1` — Pedicure · 4 behandelingen · vanaf €40 — zie Treatwell
- `beh.pedi.rating` — Pedicure ★ 4,9 op Treatwell

## Lashes (#lashes)
- `beh.lash.h2` — lashes.
- `beh.lash.p` — Wimperextensions, Russian volume en lash lift, gewerkt met onder meer Magnitica Lashes en Noble Lashes. Alle drie scoren op Treatwell gemiddeld een 5,0.
- `beh.lash.1` — Wimperextensions (classic) · prijs op aanvraag — zie Treatwell
- `beh.lash.2` — Russian volume · prijs op aanvraag — zie Treatwell
- `beh.lash.3` — Lash lift · prijs op aanvraag — zie Treatwell
- *(Interactief 2 hier — zelfde sleutels als `home.lash.*`)*

## Gezicht (#gezicht)
- `beh.face.h2` — wenkbrauwen & gezicht.
- `beh.face.p` — Wenkbrauwen en gezicht harsen, voor een verzorgde lijn en een rustig gezicht. Prijzen en mogelijkheden zie je op Treatwell.
- `beh.face.1` — Wenkbrauwen en gezicht harsen · prijs op aanvraag — zie Treatwell

## Afsluiter
- `beh.end.h2` — gekozen? | boek je moment.
- `beh.end.p` — Op Treatwell zie je de actuele prijzen en de vrije tijden. Betalen in de studio gaat contant.
- `beh.end.btn1` — Boek via Treatwell
- `beh.end.btn2` — Adres & openingstijden

---

# 3 · OVER ONS (over-ons.html)

## Meta
- `over.meta.title` — Over ons · Avvenente nail & lash studio Kaatsheuvel
- `over.meta.desc` — Een kleine, rustige nagel- en lashstudio aan de Peperstraat in Kaatsheuvel, met sojakaarsen en persoonlijke aandacht. ★ 4,9 op Treatwell.

## Hero
- `over.hero.chip` — Over Avvenente
- `over.hero.h1` — klein. rustig. | met aandacht.
- `over.hero.lead` — Avvenente is een nail & lash studio aan de Peperstraat in Kaatsheuvel. Geen fabriek, maar een plek waar het licht zacht is, de kaarsen branden en jij even de enige bent.
- `over.hero.btn1` — Boek via Treatwell
- `over.hero.btn2` — Bekijk behandelingen
- `over.hero.stat1` — ★ 4,9 · 127 reviews
- `over.hero.stat2` — Lashes ★ 5,0
- `over.hero.stat3` — Sojakaarsen in de studio

## Manifest (woorden lichten op)
- `over.manifest.p1` — We geloven dat een behandeling niet alleen draait om het resultaat, maar ook om hoe je je voelt terwijl je zit. Daarom is het hier stil, warm en zonder haast.
- `over.manifest.p2` — Er branden sojakaarsen, omdat die rustig en zacht branden. Er is tijd om te vertellen wat je wilt, en tijd om het goed te doen. Persoonlijke aandacht is geen extraatje, het is de manier van werken.
- `over.manifest.p3` — Lashes, manicure en pedicure zijn de specialiteiten. Daaromheen: BIAB, gel, gellak, nail art en harsen. Alles met dezelfde zorg, of het nu om één nagel gaat of om een hele set.

## Sfeer
- `over.sfeer.h2` — de sfeer.
- `over.sfeer.p1` — In de reviews op Treatwell komt de ontspannen sfeer steeds terug, net als de sojakaarsen. Zacht licht, een rustige tafel en tijd om te praten: meer is er niet nodig om een uur echt tot rust te komen.
- `over.sfeer.p2` — Een afspraak aan het eind van de dag? Dat kan, want doordeweeks is de studio open tot acht uur en op vrijdag tot negen. Je komt binnen met je werkdag nog in je hoofd en gaat naar huis met mooie nagels en een rustiger gevoel.
- `over.sfeer.caption` — Voorbeeldbeeld *(beeld 11)*

## Waar we voor staan (values)
- `over.values.h2` — waar we voor staan.
- `over.values.1.t` — Rust
- `over.values.1.d` — Geen lopende band. Je afspraak is jouw moment, zonder haast.
- `over.values.2.t` — Aandacht
- `over.values.2.d` — Eerst luisteren, dan beginnen. Je weet vooraf wat er gebeurt en wat het kost.
- `over.values.3.t` — Vakmanschap
- `over.values.3.d` — Vriendelijk en kundig, zo omschrijven gasten de service. Daar houden we ons aan.
- `over.values.4.t` — Eerlijk
- `over.values.4.d` — Duidelijke prijzen op Treatwell, contant betalen in de studio, geen verrassingen.

## Merken
- `over.brands.h2` — waarmee we werken.
- `over.brands.p` — Voor gel, verzorging en wimpers wordt gewerkt met merken uit de nagel- en lashwereld:
- `over.brands.list` — Elan · Thuya · Magnitica Lashes · Noble Lashes · Mistero Milano · Slowianka · Julia Nessa · Apis

## Beoordelingen
- `over.ratings.h2` — in cijfers.
- `over.ratings.intro` — Gemiddelde beoordelingen van gasten op Treatwell.
- `over.ratings.total` — ★ 4,9 · 127 reviews
- `over.ratings.1` — Eyelash Extensions · 5,0
- `over.ratings.2` — Lash Lift · 5,0
- `over.ratings.3` — Russian Volume · 5,0
- `over.ratings.4` — Pedicure · 4,9
- `over.ratings.5` — Eyebrow Waxing · 4,5
- `over.ratings.source` — bron: Treatwell
- `over.ratings.link` — Lees de reviews op Treatwell

## Afsluiter
- `over.end.h2` — kom gerust | even zitten.
- `over.end.btn1` — Boek via Treatwell
- `over.end.btn2` — Adres & openingstijden

---

# 4 · CONTACT (contact.html)

## Meta
- `contact.meta.title` — Contact & openingstijden · Avvenente Kaatsheuvel
- `contact.meta.desc` — Avvenente, Peperstraat 6A, Kaatsheuvel. Ma–do 09:00–20:00, vr 09:00–21:00. Gratis parkeren, alleen contant, boeken via Treatwell.

## Hero
- `contact.hero.chip` — Contact · Kaatsheuvel
- `contact.hero.h1` — peperstraat 6a. | kom binnen.
- `contact.hero.lead` — Gratis parkeren, een bushalte in de buurt, en doordeweeks open tot acht uur, op vrijdag tot negen. Boek je moment via Treatwell.
- `contact.hero.btn1` — Boek via Treatwell
- `contact.hero.btn2` — Route plannen
- `contact.hero.open` — Nu open · tot {close}

## Adres
- `contact.addr.h2` — adres.
- `contact.addr.line1` — Avvenente — nail & lash studio
- `contact.addr.line2` — Peperstraat 6A
- `contact.addr.line3` — Kaatsheuvel
- `contact.addr.route` — Route plannen

## Openingstijden (week + candle-line)
- `contact.hours.h2` — openingstijden.
- *(rijen: `common.hours.mon` … `common.hours.sun`, vandaag gemarkeerd met `common.hours.today`)*
- `contact.hours.closedDay` — vandaag gesloten — de kaars is uit
- `contact.hours.note` — Openingstijden volgens Treatwell.

## Bereikbaarheid
- `contact.reach.h2` — zo kom je er.
- `contact.reach.car` — Met de auto: gratis parkeren.
- `contact.reach.bus` — Met de bus: halte Kaatsheuvel, Berndijksestraat.

## Afspraak & betalen
- `contact.book.h2` — afspraak maken.
- `contact.book.p` — Afspraken maak je online via Treatwell. Daar zie je de vrije tijden en de actuele prijzen.
- `contact.book.btn` — Boek via Treatwell
- `contact.pay` — Betalen: alleen contant
- `contact.phone.label` — Telefoon
- `contact.phone.value` — Telefoon volgt
- `contact.phone.note` — Een telefoonnummer wordt binnenkort toegevoegd. Tot die tijd boek je via Treatwell.

## Afsluiter
- `contact.end.h2` — tot zo.
- `contact.end.btn1` — Boek via Treatwell
- `contact.end.btn2` — Bekijk behandelingen
